#include <stdio.h>
//#include "dht.h"
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "dht.h"
#include "C:\Espressif\frameworks\esp-idf-v5.1.2\components\esp_rom\include\esp32\rom\ets_sys.h"
#include "C:\Espressif\frameworks\esp-idf-v5.1.2\examples\lab_5\task_1\main\esp_idf_lib_helpers.h"
#define dht_pin 4

void dht_test() {
gpio_set_direction(dht_pin, GPIO_MODE_INPUT);

while (1) {
int16_t temperature, humidity; // Declare variables to store temperature and humidity
int ret = dht_read_data(DHT_TYPE_DHT11, dht_pin, &humidity, &temperature); // Pass the address of temperature and humidity variables
if (ret == ESP_OK) {
printf("Temperature: %.1f°C, Humidity: %.1f%%\n",
(float)temperature / 10.0f, (float)humidity / 10.0f); // Convert the values to float for printing
} 
else {
printf("Failed to read from DHT sensor\n");
}
vTaskDelay(2000 / portTICK_PERIOD_MS); // delay for 2 seconds
}                                                                    
}
void app_main() {
dht_test();
}
